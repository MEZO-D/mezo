import pygame as p
import ChessEngine
import sys
from multiprocessing import Process, Queue
import SmartMoveFinder
import MinMaxPlayer
import MinMaxPlayerr

BOARD_WIDTH  = 1440
BOARD_HEIGHT= 900
MOVE_LOG_PANEL_WIDTH = 250
MOVE_LOG_PANEL_HEIGHT = BOARD_HEIGHT
DIMENSION = 8
SQUARE_SIZE = BOARD_HEIGHT // DIMENSION
MAX_FPS = 15
IMAGES = {}


def loadImages():
    pieces = ["wp", "wR", "wN", "wB", "wK", "wQ", "bp", "bR", "bN", "bB", "bK", "bQ"]
    for piece in pieces:
        IMAGES[piece] = p.transform.scale(
            p.image.load("images/" + piece + ".png"), (SQUARE_SIZE, SQUARE_SIZE)
        )


def main(difficulty):
    p.init()
    screen = p.display.set_mode((BOARD_WIDTH, BOARD_HEIGHT))
    clock = p.time.Clock()
    screen.fill(p.Color("white"))
    game_state = ChessEngine.GameState()
    valid_moves = game_state.getValidMoves()
    move_made = False
    animate = False
    loadImages()
    running = True
    square_selected = ()
    ai_thinking = False
    move_finder_process = None

    if difficulty == "easy":
        white_player = SmartMoveFinder
        black_player = MinMaxPlayer
    elif difficulty == "medium":
        white_player = SmartMoveFinder
        black_player = MinMaxPlayerr
    elif difficulty == "hard":
        white_player = SmartMoveFinder
        black_player = SmartMoveFinder

    while running:
        for e in p.event.get():
            if e.type == p.QUIT:
                p.quit()
                sys.exit()

        if not game_state.checkmate and not game_state.stalemate:
            if not ai_thinking:
                ai_thinking = True
                return_queue = Queue()
                if game_state.white_to_move:
                    move_finder_process = Process(
                        target=white_player.findBestMove,
                        args=(game_state, valid_moves, return_queue),
                    )
                else:
                    move_finder_process = Process(
                        target=black_player.findBestMove,
                        args=(game_state, valid_moves, return_queue),
                    )
                move_finder_process.start()

            if not move_finder_process.is_alive():
                ai_move = return_queue.get()
                if ai_move is None:
                    if game_state.white_to_move:
                        ai_move = white_player.findRandomMove(valid_moves)
                    else:
                        ai_move = black_player.findRandomMove(valid_moves)
                game_state.makeMove(ai_move)
                move_made = True
                animate = True
                ai_thinking = False

        if move_made:
            if animate:
                animateMove(game_state.move_log[-1], screen, game_state.board, clock)
            valid_moves = game_state.getValidMoves()
            move_made = False
            animate = False

        drawGameState(screen, game_state, valid_moves, square_selected)

        if game_state.checkmate:
            if game_state.white_to_move:
                drawEndGameText(screen, "Black wins by checkmate")
            else:
                drawEndGameText(screen, "White wins by checkmate")

        elif game_state.stalemate:
            drawEndGameText(screen, "Stalemate")

        clock.tick(MAX_FPS)
        p.display.flip()


def drawGameState(screen, game_state, valid_moves, square_selected):
    drawBoard(screen)
    highlightSquares(screen, game_state, valid_moves, square_selected)
    drawPieces(screen, game_state.board)


def drawBoard(screen):
    colors = [p.Color(128, 128, 128), p.Color(255, 255, 255)]  # Custom colors
    for row in range(DIMENSION):
        for column in range(DIMENSION):
            color = colors[(row + column) % 2]
            p.draw.rect(
                screen,
                color,
                p.Rect(
                    column * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE
                ),
            )


def highlightSquares(screen, game_state, valid_moves, square_selected):
    if len(game_state.move_log) > 0:
        last_move = game_state.move_log[-1]
        s = p.Surface((SQUARE_SIZE, SQUARE_SIZE))
        s.set_alpha(100)
        s.fill(p.Color("blue"))
        screen.blit(
            s, (last_move.end_col * SQUARE_SIZE, last_move.end_row * SQUARE_SIZE)
        )
    if square_selected != ():
        row, col = square_selected
        if game_state.board[row][col][0] == ("w" if game_state.white_to_move else "b"):
            s = p.Surface((SQUARE_SIZE, SQUARE_SIZE))
            s.set_alpha(100)
            s.fill(p.Color("blue"))
            screen.blit(s, (col * SQUARE_SIZE, row * SQUARE_SIZE))

            s.fill(p.Color("yellow"))
            for move in valid_moves:
                if move.start_row == row and move.start_col == col:
                    screen.blit(
                        s, (move.end_col * SQUARE_SIZE, move.end_row * SQUARE_SIZE)
                    )


def drawPieces(screen, board):
    for row in range(DIMENSION):
        for column in range(DIMENSION):
            piece = board[row][column]
            if piece != "--":
                screen.blit(
                    IMAGES[piece],
                    p.Rect(
                        column * SQUARE_SIZE,
                        row * SQUARE_SIZE,
                        SQUARE_SIZE,
                        SQUARE_SIZE,
                    ),
                )


def drawMoveLog(screen, game_state, font):
    move_log_rect = p.Rect(BOARD_WIDTH, 0, MOVE_LOG_PANEL_WIDTH, MOVE_LOG_PANEL_HEIGHT)
    p.draw.rect(screen, p.Color("black"), move_log_rect)
    move_log = game_state.move_log
    move_texts = []
    for i in range(0, len(move_log), 2):
        move_string = str(i // 2 + 1) + ". " + str(move_log[i]) + " "
        if i + 1 < len(move_log):
            move_string += str(move_log[i + 1]) + "  "
        move_texts.append(move_string)

    moves_per_row = 3
    padding = 5
    line_spacing = 2
    text_y = padding
    for i in range(0, len(move_texts), moves_per_row):
        text = ""
        for j in range(moves_per_row):
            if i + j < len(move_texts):
                text += move_texts[i + j]

        text_object = font.render(text, True, p.Color("white"))
        text_location = move_log_rect.move(padding, text_y)
        screen.blit(text_object, text_location)
        text_y += text_object.get_height() + line_spacing


def drawEndGameText(screen, text):
    font = p.font.SysFont("Helvetica", 32, True, False)
    text_object = font.render(text, False, p.Color("gray"))
    text_location = p.Rect(0, 0, BOARD_WIDTH, BOARD_HEIGHT).move(
        BOARD_WIDTH / 2 - text_object.get_width() / 2,
        BOARD_HEIGHT / 2 - text_object.get_height() / 2,
    )
    screen.blit(text_object, text_location)
    text_object = font.render(text, False, p.Color("black"))
    screen.blit(text_object, text_location.move(2, 2))


def animateMove(move, screen, board, clock):
    colors = [p.Color(240, 217, 181), p.Color(181, 136, 99)]  # Custom colors
    d_row = move.end_row - move.start_row
    d_col = move.end_col - move.start_col
    frames_per_square = 10  # frames to move one square
    frame_count = (abs(d_row) + abs(d_col)) * frames_per_square
    for frame in range(frame_count + 1):
        row, col = (
            move.start_row + d_row * frame / frame_count,
            move.start_col + d_col * frame / frame_count,
        )
        drawBoard(screen)
        drawPieces(screen, board)
        color = colors[(move.end_row + move.end_col) % 2]
        end_square = p.Rect(
            move.end_col * SQUARE_SIZE,
            move.end_row * SQUARE_SIZE,
            SQUARE_SIZE,
            SQUARE_SIZE,
        )
        p.draw.rect(screen, color, end_square)
        if move.piece_captured != "--":
            if move.is_enpassant_move:
                enpassant_row = (
                    move.end_row + 1
                    if move.piece_captured[0] == "b"
                    else move.end_row - 1
                )
                end_square = p.Rect(
                    move.end_col * SQUARE_SIZE,
                    enpassant_row * SQUARE_SIZE,
                    SQUARE_SIZE,
                    SQUARE_SIZE,
                )
            screen.blit(IMAGES[move.piece_captured], end_square)

        screen.blit(
            IMAGES[move.piece_moved],
            p.Rect(col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE),
        )
        p.display.flip()
        clock.tick(60)


def create_chess_game(difficulty):
    p.init()
    screen = p.display.set_mode((BOARD_WIDTH, BOARD_HEIGHT))
    clock = p.time.Clock()
    screen.fill(p.Color(255, 255, 255))  # Set background color (white)
    game_state = ChessEngine.GameState()
    valid_moves = game_state.getValidMoves()
    move_made = False
    animate = False
    loadImages()
    running = True
    square_selected = ()
    ai_thinking = False
    move_finder_process = None

    while running:
        for e in p.event.get():
            if e.type == p.QUIT:
                p.quit()
                sys.exit()

        if not game_state.checkmate and not game_state.stalemate:
            if not ai_thinking:
                ai_thinking = True
                return_queue = Queue()
                if game_state.white_to_move:
                    move_finder_process = Process(
                        target=SmartMoveFinder.findBestMove,
                        args=(game_state, valid_moves, return_queue),
                    )
                else:
                    move_finder_process = Process(
                        target=MinMaxPlayer.findBestMovee,
                        args=(game_state, valid_moves, return_queue),
                    )
                move_finder_process.start()

            if not move_finder_process.is_alive():
                ai_move = return_queue.get()
                if ai_move is None:
                    if game_state.white_to_move:
                        ai_move = SmartMoveFinder.findRandomMove(valid_moves)
                    else:
                        ai_move = MinMaxPlayer.findRandomMove(valid_moves)
                game_state.makeMove(ai_move)
                move_made = True
                animate = True
                ai_thinking = False

        if move_made:
            if animate:
                animateMove(game_state.move_log[-1], screen, game_state.board, clock)
            valid_moves = game_state.getValidMoves()
            move_made = False
            animate = False

        drawGameState(screen, game_state, valid_moves, square_selected)

        if game_state.checkmate:
            if game_state.white_to_move:
                drawEndGameText(screen, "Black wins by checkmate")
            else:
                drawEndGameText(screen, "White wins by checkmate")

        elif game_state.stalemate:
            drawEndGameText(screen, "Stalemate")

        clock.tick(MAX_FPS)
        p.display.flip()

def button_hover(button, hover_color, shadow_color, shadow_offset):
    # Draw button shadow
    shadow_rect = p.Rect(button.x + shadow_offset[0], button.y + shadow_offset[1], button.width, button.height)
    p.draw.rect(window, shadow_color, shadow_rect)

    # Draw button with hover color and rounded edges
    p.draw.rect(window, hover_color, button, border_radius=10)

if __name__ == "__main__":
    p.init()
    window_width = 1440
    window_height =900
    window = p.display.set_mode((window_width, window_height))
    p.display.set_caption("Chess Game")
    background = p.image.load("img.png").convert()
    background = p.transform.scale(background, (window_width, window_height))

    easy_button_width = 150
    easy_button_height = 50
    easy_button_x = (window_width - easy_button_width) // 2
    easy_button_y = (window_height - easy_button_height) // 2 - 100
    easy_button = p.Rect(easy_button_x, easy_button_y, easy_button_width, easy_button_height)

    medium_button_width = 150
    medium_button_height = 50
    medium_button_x = (window_width - medium_button_width) // 2
    medium_button_y = (window_height - medium_button_height) // 2
    medium_button = p.Rect(medium_button_x, medium_button_y, medium_button_width, medium_button_height)

    hard_button_width = 150
    hard_button_height = 50
    hard_button_x = (window_width - hard_button_width) // 2
    hard_button_y = (window_height - hard_button_height) // 2 + 100
    hard_button = p.Rect(hard_button_x, hard_button_y, hard_button_width, hard_button_height)

    # Shadow configuration
    shadow_color = (0, 0, 0)
    shadow_offset = (3, 3)

    while True:
        window.blit(background, (0, 0))

        # Check for button hover
        mouse_pos = p.mouse.get_pos()
        if easy_button.collidepoint(mouse_pos):
            button_hover(easy_button, (0, 0, 255), shadow_color, shadow_offset)
        elif medium_button.collidepoint(mouse_pos):
            button_hover(medium_button, (0, 0, 255), shadow_color, shadow_offset)
        elif hard_button.collidepoint(mouse_pos):
            button_hover(hard_button, (0, 0, 255), shadow_color, shadow_offset)
        else:
            # Draw normal buttons with rounded edges
            p.draw.rect(window, (0, 0, 0), easy_button, border_radius=10)
            p.draw.rect(window, (0, 0, 0), medium_button, border_radius=10)
            p.draw.rect(window, (0, 0, 0), hard_button, border_radius=10)

        font = p.font.SysFont("Arial", 24)

        easy_text = font.render("Easy", True, (255, 255, 255))
        easy_text_rect = easy_text.get_rect(center=easy_button.center)

        medium_text = font.render("Medium", True, (255, 255, 255))
        medium_text_rect = medium_text.get_rect(center=medium_button.center)

        hard_text = font.render("Hard", True, (255, 255, 255))
        hard_text_rect = hard_text.get_rect(center=hard_button.center)

        window.blit(easy_text, easy_text_rect)
        window.blit(medium_text, medium_text_rect)
        window.blit(hard_text, hard_text_rect)

        # Add title "Chess Game" to the window
        title_font = p.font.SysFont("Arial", 36, bold=True)
        title_text = title_font.render("Chess Game", True, (255, 255, 255))
        title_text_rect = title_text.get_rect(center=(window_width // 2, 50))
        window.blit(title_text, title_text_rect)

        p.display.update()

        for event in p.event.get():
            if event.type == p.QUIT:
                p.quit()
                sys.exit()
            elif event.type == p.MOUSEBUTTONDOWN:
                if easy_button.collidepoint(event.pos):
                    main("easy")
                elif medium_button.collidepoint(event.pos):
                    main("medium")
                elif hard_button.collidepoint(event.pos):
                    main("hard")