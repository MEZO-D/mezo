<head>
    <link rel="stylesheet" type="text/css" href="cssfile.css">
</head>

<header>
    <div class="nav">
        <ul>
            <li><a class=" happ" href="#" target="_self">Firstpage </a></li>
            <li><a class=" happ" href="index.php" target="_self"> SecPage</a></li>
            <li><a class=" happ" href="#" target="_self">Basic3</a></li>
            <li><a class=" happ" href="#" target="_self">Basic4</a></li>
            <li><a class=" happ" href="#" target="_self">Basic5</a></li>
            <li><a class=" happ" href="#" target="_self">Basic6</a></li>
            <li><a class=" happ" href="#" target="_self">Basic7</a></li>
            <li><a class=" happ" href="#" target="_self">Basic8</a></li>
            <li><a class=" happ" href="#" target="_self">Basic9</a></li>


        </ul>
    </div>

</header>