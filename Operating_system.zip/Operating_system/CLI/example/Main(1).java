package com.example;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Terminal terminal = new Terminal();

        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine();

            if (input.equals("exit")) {
                break;
            }

            List<Command> commands = Parser.parseCommands(input);

            for (Command command : commands) {
                executeCommand(terminal, command);
            }
        }

        scanner.close();
    }

    private static void executeCommand(Terminal terminal, Command command) {
        switch (command.getName()) {
            case "date":
                terminal.date();
                break;
            case "pwd":
                terminal.pwd();
                break;
            case "clear":
                terminal.clear();
                break;
            case "cd":
                terminal.cd(command.getArguments());
                break;
            case "ls":
                terminal.ls(command.getArguments());
                break;
            case "cp":
                terminal.cp(command.getArguments());
                break;
            case "mv":
                terminal.mv(command.getArguments());
                break;
            case "rm":
                terminal.rm(command.getArguments());
                break;
            case "mkdir":
                terminal.mkdir(command.getArguments());
                break;
            case "rmdir":
                terminal.rmdir(command.getArguments());
                break;
            case "cat":
                terminal.cat(command.getArguments());
                break;
            case "more":
                terminal.more(command.getArguments());
                break;
            case "help":
                terminal.help(command.getArguments());
                break;
            case ">":
                terminal.redirectOutput(command.getArguments(), false);
                break;
            case ">>":
                terminal.redirectOutput(command.getArguments(), true);
                break;
            default:
                System.out.println("Invalid command.");
        }
    }
}
