package com.example;

import java.util.ArrayList;
import java.util.List;

public class Parser {
    public static List<Command> parseCommands(String input) {
        String[] commandTokens = input.trim().split("\\s*&\\s*");

        List<Command> commandList = new ArrayList<>();

        for (String commandToken : commandTokens) {
            Command command = parseCommand(commandToken);
            commandList.add(command);
        }

        return commandList;
    }

    public static Command parseCommand(String input) {
        String[] tokens = input.trim().split("\\s+");
        String commandName = tokens[0];

        List<String> argumentList = new ArrayList<>();
        StringBuilder currentArgument = new StringBuilder();
        boolean insideQuotes = false;

        // Process the tokens and handle quotes
        for (int i = 1; i < tokens.length; i++) {
            String token = tokens[i];

            if (!insideQuotes && token.startsWith("\"")) {
                // Argument starts with a quote, mark as inside quotes and append to currentArgument
                insideQuotes = true;
                currentArgument.append(token.substring(1));
            } else if (insideQuotes && token.endsWith("\"")) {
                // Argument ends with a quote, mark as outside quotes, append to currentArgument, and add to argumentList
                insideQuotes = false;
                currentArgument.append(" ").append(token.substring(0, token.length() - 1));
                argumentList.add(Parser.removeQuotes(currentArgument.toString()));
                currentArgument.setLength(0); // Reset currentArgument
            } else if (insideQuotes) {
                // Argument is inside quotes, just append to currentArgument
                currentArgument.append(" ").append(token);
            } else {
                // Argument is not inside quotes, add to argumentList directly
                argumentList.add(token);
            }
        }

        return new Command(commandName, argumentList);
    }

    public static String removeQuotes(String argument) {
        if (argument.startsWith("\"") && argument.endsWith("\"")) {
            return argument.substring(1, argument.length() - 1);
        }
        return argument;
    }
}
