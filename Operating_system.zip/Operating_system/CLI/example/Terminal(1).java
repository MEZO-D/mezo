package com.example;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;



public class Terminal {
     private Map<String, String> commandDescriptions;
     public Terminal() {
        commandDescriptions = new HashMap<>();
        commandDescriptions.put("date", "Prints the current date and time.");
        commandDescriptions.put("pwd", "Prints the current working directory.");
        commandDescriptions.put("clear", "Clears the terminal screen.");
        commandDescriptions.put("cd", "Changes the current directory. Usage: cd <directory>");
        commandDescriptions.put("ls", "Lists files and directories in the current directory or a specified directory. Usage: ls [directory]");
        commandDescriptions.put("cp", "Copies a file from source to destination. Usage: cp <source> <destination>");
        commandDescriptions.put("mv", "Moves a file from source to destination. Usage: mv <source> <destination>");
        commandDescriptions.put("rm", "Removes a file. Usage: rm <file>");
        commandDescriptions.put("mkdir", "Creates a new directory. Usage: mkdir <directory>");
        commandDescriptions.put("rmdir", "Removes a directory. Usage: rmdir <directory>");
        commandDescriptions.put("cat", "Displays the contents of a file. Usage: cat <file>");
        commandDescriptions.put("more", "Displays the contents of a file one page at a time. Usage: more <file>");
        commandDescriptions.put("help", "Displays information about available commands. Usage: help [command]");
        commandDescriptions.put(">", "Redirects the output of a command to a file. Usage: command > FileName");
        commandDescriptions.put(">>", "Appends the output of a command to a file. Usage: command >> FileName");
    }
    public void help(List<String> arguments) {
        if (arguments.isEmpty()) {
            // Display help for all commands
            for (String command : commandDescriptions.keySet()) {
                System.out.printf("%-10s %s%n", command, commandDescriptions.get(command));
            }
        } else {
            // Display help for a specific command
            String command = arguments.get(0);
            String description = commandDescriptions.get(command);
            if (description != null) {
                System.out.printf("%-10s %s%n", command, description);
            } else {
                System.out.println("Command not found: " + command);
            }
        }
    }

    public void date() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date currentDate = new Date();
        System.out.println(dateFormat.format(currentDate));
    }

    public void pwd() {
        String currentDirectory = System.getProperty("user.dir");
        System.out.println(currentDirectory);
    }

    public void clear() {
        for (int i = 0; i < 100; i++) {
            System.out.println();}
    }

    public void cd(List<String> arguments) {
        if (arguments.size() != 1) {
            System.out.println("Invalid number of arguments for 'cd' command.");
            return;
        }

        String directory = arguments.get(0);
        try {
            File file = new File(directory);
            if (file.isDirectory()) {
                System.setProperty("user.dir", file.getCanonicalPath());
            } else {
                System.out.println("Directory does not exist: " + directory);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void ls(List<String> arguments) {
        File directory;
        if (arguments.size() == 0) {
            directory = new File(System.getProperty("user.dir"));
        } else if (arguments.size() == 1) {
            directory = new File(arguments.get(0));
        } else {
            System.out.println("Invalid number of arguments for 'ls' command.");
            return;
        }

        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    System.out.println(file.getName());
                }
            }
        } else {
            System.out.println("Not a directory: " + directory.getAbsolutePath());
        }
    }

   
   public void cp(List<String> arguments) {
    if (arguments.size() != 2) {
        System.out.println("Invalid number of arguments for 'cp' command. Expected 2 arguments.");
        return;
    }

    String sourcePath = arguments.get(0);
    String destinationPath = arguments.get(1);

    try {
        Path source = Paths.get(sourcePath);
        Path destination = Paths.get(destinationPath);

        if (!Files.exists(source)) {
            System.out.println("Source file or directory does not exist: " + sourcePath);
            return;
        }

        if (Files.isDirectory(destination)) {
            destination = destination.resolve(source.getFileName());
            if (Files.isDirectory(source)) {
                copyDirectory(source, destination);
            } else {
                Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
            }
        } else {
            // If the destination is not a directory, copy the source file
            System.out.println("Source copied successfully from '" + sourcePath + "' to '" + destinationPath + "'");
        }

        System.out.println("Source copied successfully from '" + sourcePath + "' to '" + destinationPath + "'");
    } catch (IOException e) {
        e.printStackTrace();
    }
}

private void copyDirectory(Path source, Path destination) throws IOException {
    Files.walkFileTree(source, new SimpleFileVisitor<Path>() {
        @Override
        public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
            Path targetDir = destination.resolve(source.relativize(dir));
            try {
                Files.copy(dir, targetDir);
            } catch (FileAlreadyExistsException e) {
                if (!Files.isDirectory(targetDir)) {
                    throw e;
                }
            }
            return FileVisitResult.CONTINUE;
        }

        @Override
        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
            Files.copy(file, destination.resolve(source.relativize(file)), StandardCopyOption.REPLACE_EXISTING);
            return FileVisitResult.CONTINUE;
        }
    });
}

    
    

    public void mv(List<String> arguments) {
        if (arguments.size() != 2) {
            System.out.println("Invalid number of arguments for 'mv' command.");
            return;
        }
    
        String sourcePath = arguments.get(0).replaceAll("^\"|\"$", ""); // Remove surrounding quotes if present
        String destinationPath = arguments.get(1);
    
        try {
            Path source = Paths.get(sourcePath);
            Path destination = Paths.get(destinationPath);
    
            if (Files.isDirectory(destination)) {
                // Move the file into the destination directory with a new name
                Path newFilePath = destination.resolve(source.getFileName());
                Files.move(source, newFilePath, StandardCopyOption.REPLACE_EXISTING);
            } else {
                // Overwrite the existing file
                Files.move(source, destination, StandardCopyOption.REPLACE_EXISTING);
            }
    
            System.out.println("File or directory moved successfully.");
        } catch (IOException e) {
            System.out.println("Error moving the file or directory:");
            e.printStackTrace();
        }
    }
    
    
    
    
    public void rm(List<String> arguments) {
        if (arguments.size() != 1) {
            System.out.println("Invalid number of arguments for 'rm' command.");
            return;
        }

        String filePath = arguments.get(0);
        try {
            Path file = Paths.get(filePath);
            Files.delete(file);
            System.out.println("File deleted successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void mkdir(List<String> arguments) {
        if (arguments.isEmpty()) {
            System.out.println("Missing directory name.");
            return;
        }

        for (String dirArgument : arguments) {
            Path newDirPath;
            if (dirArgument.contains("/") || dirArgument.contains("\\")) {
                // If the argument contains a slash, it's a full or short path
                newDirPath = Paths.get(dirArgument).toAbsolutePath();
            } else {
                // Otherwise, it's a directory name to be created in the current directory
                newDirPath = Paths.get(System.getProperty("user.dir"), dirArgument);
            }

            try {
                Files.createDirectories(newDirPath);
                System.out.println("Directory created successfully: " + newDirPath);
            } catch (FileAlreadyExistsException e) {
                System.out.println("Directory already exists: " + newDirPath);
            } catch (IOException e) {
                System.out.println("Error creating directory: " + newDirPath);
            }
        }
    }

    public void rmdir(List<String> arguments) {
        if (arguments.size() != 1) {
            System.out.println("Invalid number of arguments for 'rmdir' command. Expected 1 argument.");
            return;
        }
    
        String targetDirectoryPath = arguments.get(0);
    
        // Case 1: Remove all empty directories in the current directory
        if (targetDirectoryPath.equals("*")) {
            File currentDirectory = new File(System.getProperty("user.dir"));
            removeEmptyDirectories(currentDirectory);
        } else {
            // Case 2: Remove the specified directory if it is empty
            File targetDirectory = new File(targetDirectoryPath);
            removeEmptyDirectory(targetDirectory);
        }
    }
    
    private void removeEmptyDirectories(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    removeEmptyDirectory(file); // Recursively remove empty subdirectories
                }
            }
        }
    }
    
    private void removeEmptyDirectory(File directory) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files == null || files.length == 0) {
                boolean deleted = directory.delete();
                if (deleted) {
                    System.out.println("Removed empty directory: " + directory.getAbsolutePath());
                } else {
                    System.out.println("Failed to remove directory: " + directory.getAbsolutePath());
                }
            }
        }
    }
    
    
    public void cat(List<String> arguments) {
        if (arguments.isEmpty()) {
            System.out.println("Missing file names.");
            return;
        }
    
        List<String> lines = new ArrayList<>();
    
        for (String filePath : arguments) {
            Path fullPath = Paths.get(filePath);
    
            if (!Files.exists(fullPath)) {
                // File does not exist with the provided path, attempt to find it in the current directory
                Path currentDirPath = Paths.get(System.getProperty("user.dir"), filePath);
                if (Files.exists(currentDirPath)) {
                    fullPath = currentDirPath;
                } else {
                    System.out.println("File not found: " + filePath);
                    continue;
                }
            }
    
            try {
                // Read lines from the file
                lines.addAll(Files.readAllLines(fullPath));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    
        // Print the concatenated content of the files
        for (String line : lines) {
            System.out.println(line);
        }
    }
    
    
    
    

   public void more(List<String> arguments) {
    if (arguments.size() != 1) {
        System.out.println("Invalid number of arguments for 'more' command.");
        return;
    }

    String filePath = arguments.get(0);
    try {
        List<String> lines = Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);
        Scanner scanner = new Scanner(System.in);

        int linesPerPage = 10;
        int currentPage = 0;
        while (currentPage * linesPerPage < lines.size()) {
            for (int i = currentPage * linesPerPage; i < (currentPage + 1) * linesPerPage && i < lines.size(); i++) {
                System.out.println(lines.get(i));
            }
            System.out.print("Press Enter for more or type 'q' to quit: ");
            String input = scanner.nextLine();
            if (input.trim().equalsIgnoreCase("q")) {
                break;
            }
            currentPage++;
        }
    } catch (IOException e) {
        System.out.println("An error occurred while reading the file: " + e.getMessage());
    }
}
    
   
public void redirectOutput(List<String> arguments, boolean append) {
    if (arguments.size() < 3) {
        System.out.println("Invalid number of arguments for redirect command.");
        return;
    }

    String outputRedirect = arguments.get(arguments.size() - 1);
    String redirectOperator = arguments.get(arguments.size() - 2);
    String commandName = arguments.get(0);
    List<String> commandArgs = arguments.subList(1, arguments.size() - 2);

    if (!redirectOperator.equals(">") && !redirectOperator.equals(">>")) {
        System.out.println("Invalid redirect operator. Supported operators are \">\" and \">>\".");
        return;
    }

    String commandOutput = executeCommand(commandName, commandArgs);

    try {
        File file = new File(outputRedirect);
        if (!file.exists()) {
            file.createNewFile();
        }

        FileWriter fileWriter = new FileWriter(file, append);
        fileWriter.write(commandOutput);
        fileWriter.close();

        System.out.println("Output redirected successfully.");
    } catch (IOException e) {
        e.printStackTrace();
    }
}

private String executeCommand(String commandName, List<String> commandArgs) {
    // Implement the logic for all existing commands, including "> and ">>".
    // ... Your existing executeCommand logic ...

    // Example: Handling "ls" command
    if (commandName.equals("ls")) {
        // Get the current working directory and list the files/directories
        String currentDir = System.getProperty("user.dir");
        File directory = new File(currentDir);
        File[] files = directory.listFiles();
        if (files != null) {
            StringBuilder output = new StringBuilder();
            for (File file : files) {
                output.append(file.getName()).append("\n");
            }
            return output.toString();
        } else {
            return "No files/directories found.";
        }
    }

    // ... Handle other commands similarly ...

    return "Invalid command.";
}
}
  

