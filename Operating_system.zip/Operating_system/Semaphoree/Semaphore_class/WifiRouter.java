class WifiRouter {
    private boolean[] connected;
    private int maxDevices, currentConnectedDevices;
    public Semaphore routerSemaphore;

    WifiRouter(int maxDevices) {
        this.maxDevices = maxDevices;
        routerSemaphore = new Semaphore(maxDevices);
        connected = new boolean[maxDevices];
    }

    public synchronized int connectDevice(WifiDevice device) throws InterruptedException {
        for (int i = 0; i < maxDevices; i++) {
            if (!connected[i]) {
                currentConnectedDevices++;
                device.deviceConnectionID = i + 1;
                connected[i] = true;
                sleep(100);
                break;
            }
        }
        return device.deviceConnectionID;
    }

    public synchronized void disconnectDevice(WifiDevice device) {
        currentConnectedDevices--;
        connected[device.deviceConnectionID - 1] = false;
        notify();
       
    }

    public synchronized void deviceArrived(WifiDevice device) {
        //System.out.println(device.deviceName + " (" + device.deviceType + ")" + " arrived");
    }

    private void sleep(int i) {
        // Implement sleep logic
    }
}