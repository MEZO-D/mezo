import java.util.Scanner;

public class NetworkSimulation {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of Wi-Fi Connections: ");
        int maxConnections = scanner.nextInt();

        System.out.print("Enter the number of devices clients want to connect: ");
        int numDevices = scanner.nextInt();

        WifiRouter router = new WifiRouter(maxConnections);

        WifiDevice[] devices = new WifiDevice[numDevices];
        Thread[] threads = new Thread[numDevices];
        for (int i = 0; i < numDevices; i++) {
            System.out.print("Enter device " + (i + 1) + " name and type: ");
            String name = scanner.next();
            String type = scanner.next();

            devices[i] = new WifiDevice(name, type, router);
            threads[i] = new Thread(devices[i]);

        }

        for (Thread thread : threads) {
            thread.start();
        }

        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        scanner.close();
    }
}