import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

class WifiDevice extends Thread {
    protected String deviceName, deviceType;
    protected int deviceConnectionID;
    protected WifiRouter deviceRouter;
    private boolean isWaiting = false;

    public WifiDevice(String name, String type, WifiRouter router) {
        this.deviceName = name;
        this.deviceType = type;
        this.deviceRouter = router;
        deviceConnectionID = 1;
    }

    @Override
    public void run() {
        try {
            deviceRouter.deviceArrived(this);
            isWaiting = true;
            deviceRouter.routerSemaphore.acquire(this);
    
            deviceConnectionID = deviceRouter.connectDevice(this); // Connect the device and get the correct connection ID
            
            String logMessage = "Connection " + deviceConnectionID + ": " + deviceName + " Occupied";
            writeToLogFile(logMessage);
    
            logMessage = "Connection " + deviceConnectionID + ": " + deviceName + " Login";
            writeToLogFile(logMessage);
    
            performOnlineActivity();
    
            deviceRouter.disconnectDevice(this);
    
            logMessage = "Connection " + deviceConnectionID + ": " + deviceName + " Logged out";
            writeToLogFile(logMessage);
    
            deviceRouter.routerSemaphore.release();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    

    private void performOnlineActivity() throws InterruptedException {
        String logMessage = "Connection " + deviceConnectionID + ": " + deviceName + " Performs online activity";
        writeToLogFile(logMessage);

        sleep(2000);
    }

    private void writeToLogFile(String message) {
        try {
            FileWriter fileWriter = new FileWriter("log.txt", true); // Append mode
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.println(message);
            printWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getDeviceConnectionID() {
        return deviceConnectionID;
    }

    public void setWaiting(boolean waiting) {
        isWaiting = waiting;
    }

    public boolean isWaiting() {
        return isWaiting;
    }

    public boolean isConnected() {
        return deviceConnectionID != -1;
    }
}
