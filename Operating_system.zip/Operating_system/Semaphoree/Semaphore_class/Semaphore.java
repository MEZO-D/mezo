import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

class Semaphore {
    private int availablePermits;

    public Semaphore(int permits) {
        this.availablePermits = permits;
    }

    public synchronized void acquire(WifiDevice device) throws InterruptedException {
        while (availablePermits <= 0) {

            String logMessage = device.deviceName + " (" + device.deviceType + ")" + " arrived and waiting";
            writeToLogFile(logMessage);
            wait();
        }

        availablePermits--;
        System.out.println("Done Succeful");
        String logMessage = device.deviceName + " (" + device.deviceType + ")" + " arrived";
        writeToLogFile(logMessage);
        device.deviceRouter.connectDevice(device);
    }

    private void writeToLogFile(String logMessage) {
        try {
            FileWriter fileWriter = new FileWriter("log.txt", true); // Append mode
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.println(logMessage);
            printWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized void release() {
        availablePermits++;
        if (availablePermits > 0) {
            notify();
        }
    }
}