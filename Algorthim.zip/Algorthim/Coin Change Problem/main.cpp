#include <iostream>
#include <vector>
#include <climits>
#include <algorithm>// for reverse
#include <chrono>  // for measuring time
#include <functional>

using namespace std;
using namespace std::chrono;
void minCoinsDP(vector<int>& coins, int target) {
    vector<int> dp(target + 1, INT_MAX);
    dp[0] = 0;

    vector<int> lastCoinUsed(target + 1, -1);

    for (int i = 1; i <= target; ++i) {
        for (int coin : coins) {
            if (i >= coin && dp[i - coin] != INT_MAX && dp[i - coin] + 1 < dp[i]) {
                dp[i] = dp[i - coin] + 1;
                lastCoinUsed[i] = coin;
            }
        }
    }

    if (dp[target] == INT_MAX) {
        cout << "Cannot make up the target amount using the given coin denominations." << endl;
        return;
    }

    cout << "Target Amount: " << target << ", Minimum Coins Needed: " << dp[target] << endl;
    cout << "Coins used: ";
    while (target > 0) {
        cout << lastCoinUsed[target] << " ";
        target -= lastCoinUsed[target];
    }
    cout << endl;
}
int minCoinsRecursive(vector<int>& coins, int target) {
    if (target == 0) {
        return 0;
    }

    int result = INT_MAX;

    for (int coin : coins) {
        if (target >= coin) {
            int subproblem = minCoinsRecursive(coins, target - coin);
            if (subproblem != INT_MAX && subproblem + 1 < result) {
                result = subproblem + 1;
            }
        }
    }

    return result;

}
void measureTime(function<void()> functionToMeasure, const string& label) {
    auto start = high_resolution_clock::now();
    functionToMeasure();
    auto end = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(end - start);
    cout << label << " Execution Time: " << duration.count() << " ms" << endl;
}


int main() {

    int coinCount;
    cout << "Enter the number of coin denominations: ";
    cin >> coinCount;

    vector<int> coinDenominations(coinCount);
    cout << "Enter the coin denominations: ";
    for (int i = 0; i < coinCount; ++i) {
        cin >> coinDenominations[i];
    }

    int targetAmount;
    cout << "Enter the target amount: ";
    cin >> targetAmount;

     measureTime([&coinDenominations, targetAmount]() {
        minCoinsDP(coinDenominations, targetAmount);
    }, "Dynamic Programming");

      measureTime([&coinDenominations, targetAmount]() {
        int result = minCoinsRecursive(coinDenominations, targetAmount);
        cout << "Target Amount: " << targetAmount << ", Minimum Coins Needed: " << result << endl;
    }, "Recursive");

    return 0;
}
