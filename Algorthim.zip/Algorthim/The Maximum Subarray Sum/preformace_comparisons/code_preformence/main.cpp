#include <iostream>
#include <vector>
#include <algorithm>
#include <limits>
#include <chrono>
#include <random> // For random number generation

using namespace std;
using namespace std::chrono;

struct SubArray {
    int left;
    int right;
    int sum;
};

SubArray bruteForceMaxSubArraySum(vector<int>& arr) {
    int n = arr.size();
    SubArray max_subarray = {0, 0, numeric_limits<int>::min()};

    for (int i = 0; i < n; i++) {
        int current_sum = 0;
        for (int j = i; j < n; j++) {
            current_sum += arr[j];
            if (current_sum > max_subarray.sum) {
                max_subarray.sum = current_sum;
                max_subarray.left = i;
                max_subarray.right = j;
            }
        }
    }

    return max_subarray;
}

SubArray maxCrossingSum(vector<int>& arr, int l, int m, int r) {
    int sum = 0;
    int left_sum = numeric_limits<int>::min();
    int max_left;

    for (int i = m; i >= l; i--) {
        sum += arr[i];
        if (sum > left_sum) {
            left_sum = sum;
            max_left = i;
        }
    }

    sum = 0;
    int right_sum = numeric_limits<int>::min();
    int max_right;

    for (int i = m + 1; i <= r; i++) {
        sum += arr[i];
        if (sum > right_sum) {
            right_sum = sum;
            max_right = i;
        }
    }

    return {max_left, max_right, left_sum + right_sum};
}

SubArray maxSubArraySum(vector<int>& arr, int l, int r) {
    if (l == r)
        return {l, r, arr[l]};

    int m = (l + r) / 2;

    SubArray left_max = maxSubArraySum(arr, l, m);
    SubArray right_max = maxSubArraySum(arr, m + 1, r);
    SubArray crossing_max = maxCrossingSum(arr, l, m, r);

    if (left_max.sum >= right_max.sum && left_max.sum >= crossing_max.sum)
        return left_max;
    else if (right_max.sum >= left_max.sum && right_max.sum >= crossing_max.sum)
        return right_max;
    else
        return crossing_max;
}

int main() {
    int n;
    cout<<"Enter the array size\n";
    cin >> n;

    vector<int> arr(n);

    // Generate random elements for the array
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(-100, 100); // Adjust the range as needed

    for (int i = 0; i < n; i++) {
        arr[i] = dis(gen);
    }

    auto start_dc = high_resolution_clock::now();
    SubArray max_subarray_dc = maxSubArraySum(arr, 0, n - 1);
    auto end_dc = high_resolution_clock::now();
    auto duration_dc = duration_cast<microseconds>(end_dc - start_dc);

    auto start_bf = high_resolution_clock::now();
    SubArray max_subarray_bf = bruteForceMaxSubArraySum(arr);
    auto end_bf = high_resolution_clock::now();
    auto duration_bf = duration_cast<microseconds>(end_bf - start_bf);

    cout << "Divide and Conquer approach:" << endl;
    cout << "Maximum subarray sum: " << max_subarray_dc.sum << endl;
    cout << "Execution time: " << duration_dc.count() << " microseconds" << endl;

    cout << "\nBrute Force approach:" << endl;
    cout << "Maximum subarray sum: " << max_subarray_bf.sum << endl;
    cout << "Execution time: " << duration_bf.count() << " microseconds" << endl;

    return 0;
}
