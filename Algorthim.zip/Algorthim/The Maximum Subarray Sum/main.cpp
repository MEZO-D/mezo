#include <iostream>
#include <vector>
#include <algorithm>
#include <limits>

using namespace std;

struct SubArray {
    int left;
    int right;
    int sum;
};

SubArray maxCrossingSum(vector<int>& arr, int l, int m, int r) {
    int sum = 0;
    int left_sum = numeric_limits<int>::min();
    int max_left;

    for (int i = m; i >= l; i--) {
        sum += arr[i];
        if (sum > left_sum) {
            left_sum = sum;
            max_left = i;
        }
    }

    sum = 0;
    int right_sum = numeric_limits<int>::min();
    int max_right;

    for (int i = m + 1; i <= r; i++) {
        sum += arr[i];
        if (sum > right_sum) {
            right_sum = sum;
            max_right = i;
        }
    }

    return {max_left, max_right, left_sum + right_sum};
}

SubArray maxSubArraySum(vector<int>& arr, int l, int r) {
    if (l == r)
        return {l, r, arr[r]};

    int m = (l + r) / 2;

    SubArray left_max = maxSubArraySum(arr, l, m);
    SubArray right_max = maxSubArraySum(arr, m + 1, r);
    SubArray crossing_max = maxCrossingSum(arr, l, m, r);
     cout << "ss\n ";
    if (left_max.sum >= right_max.sum && left_max.sum >= crossing_max.sum)
         {cout << "left ";
         return left_max;}

    else if (right_max.sum >= left_max.sum && right_max.sum >= crossing_max.sum)
       {cout << "right ";
        return right_max;}
    else
        {cout << "cross ";
       return crossing_max;}

}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;

    vector<int> arr(n);

    for (int i = 0; i < n; i++) {
    cout << "Enter the element number"<<"["<<i+1<<"]: ";
        cin >> arr[i];
    }

    SubArray max_subarray = maxSubArraySum(arr, 0, n - 1);
    cout << "Maximum subarray sum: " << max_subarray.sum << endl;
    cout << "Subarray: [";
    for (int i = max_subarray.left; i <= max_subarray.right; i++) {
        cout << arr[i];
        if (i < max_subarray.right) {
            cout << ", ";
        }
    }
    cout << "]" << endl;


    return 0;
}
