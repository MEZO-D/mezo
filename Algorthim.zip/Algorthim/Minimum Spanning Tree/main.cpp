#include <iostream>
#include <vector>
#include <queue>
using namespace std;

class Graph {
public:
    int V;
    vector<vector<pair<int, int>>> adj;

    Graph(int V) : V(V), adj(V) {}

    void addEdge(int u, int v, int weight) {
        adj[u].emplace_back(v, weight);
        adj[v].emplace_back(u, weight);
    }

    vector<pair<int, int>> primMST(int start) {
        vector<int> key(V, INT_MAX);
        vector<int> parent(V, -1);
        vector<bool> inQueue(V, true);

        key[start] = 0;

        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
        pq.push(make_pair(0, start));

        while (!pq.empty()) {
            int u = pq.top().second;
            pq.pop();
            inQueue[u] = false;

            for (const auto &neighbor : adj[u]) {
                int v = neighbor.first;
                int weight = neighbor.second;

                if (inQueue[v] && weight < key[v]) {
                    parent[v] = u;
                    key[v] = weight;
                    pq.push(make_pair(key[v], v));
                }
            }
        }

        vector<pair<int, int>> mstEdges;
        for (int i = 0; i < V; ++i) {
            if (parent[i] != -1) {
                mstEdges.emplace_back(parent[i], i);
            }
        }

        return mstEdges;
    }
};

int main() {
    int V, E;
    cout << "Enter the number of vertices and edges: ";
    cin >> V >> E;

    Graph graph(V);

    cout << "Enter edges in the format (u v weight):\n";
    for (int i = 0; i < E; ++i) {
        int u, v, weight;
        cin >> u >> v >> weight;
        graph.addEdge(u, v, weight);
    }

    int startVertex;
    cout << "Enter the starting vertex: ";
    cin >> startVertex;

    vector<pair<int, int>> mst = graph.primMST(startVertex);

    cout << "MST edges:\n";
    for (const auto &edge : mst) {
        cout << edge.first << " - " << edge.second << "\n";
    }

    return 0;
}
