#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
#include <chrono>
using namespace std;
using namespace std::chrono;

struct Edge {
    int src, dest, weight;
};

class Graph {
public:
    int V, E;
    vector<Edge> edges;

    Graph(int V, int E) : V(V), E(E) {}

    void addEdge(int src, int dest, int weight) {
        edges.push_back({src, dest, weight});
    }
};

int calculateMSTWeight(const Graph& graph, const vector<int>& selectedEdges) {
    int totalWeight = 0;
    for (int edgeIdx : selectedEdges) {
        totalWeight += graph.edges[edgeIdx].weight;
    }
    return totalWeight;
}

void bruteForceMST(const Graph& graph) {
    int V = graph.V;
    int E = graph.E;

    vector<int> allEdges(E);
    for (int i = 0; i < E; ++i) {
        allEdges[i] = i;
    }

    vector<int> minMST;
    int minWeight = INT_MAX;

    do {
        vector<int> selectedEdges;
        for (int i = 0; i < V - 1; ++i) {
            selectedEdges.push_back(allEdges[i]);
        }

        int mstWeight = calculateMSTWeight(graph, selectedEdges);
        if (mstWeight < minWeight) {
            minWeight = mstWeight;
            minMST = selectedEdges;
        }
    } while (next_permutation(allEdges.begin(), allEdges.end()));

    cout << "Minimum Spanning Tree Edges:" << endl;
    for (int edgeIdx : minMST) {
        const Edge& edge = graph.edges[edgeIdx];
        cout << "Edge: " << edge.src << " - " << edge.dest << ", Weight: " << edge.weight << endl;
    }
    cout << "Minimum Spanning Tree Weight: " << minWeight << endl;
}

int main() {
    int V, E;
    cout << "Enter the number of vertices and edges: ";
    cin >> V >> E;

    Graph graph(V, E);

    cout << "Enter edges in the format: Source Destination Weight" << endl;
    for (int i = 0; i < E; ++i) {
        int src, dest, weight;
        cin >> src >> dest >> weight;
        graph.addEdge(src, dest, weight);
    }

    auto start = high_resolution_clock::now();
    bruteForceMST(graph);
    auto end = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(end - start);
    cout << "Brute Force Execution Time: " << duration.count() << " ms" << endl;

    return 0;
}
