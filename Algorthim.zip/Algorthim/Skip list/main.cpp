#include <iostream>
#include <cstdlib>
#include <ctime>
#include <climits>
using namespace std;

const int MAX_LEVEL = 3;  // Maximum level of the skip list

// Node class for skip list
class Node {
public:
    int value;
    Node** forward;  // Array of pointers to forward nodes

    Node(int level, int value) {
        this->value = value;
        forward = new Node*[level + 1];
        fill_n(forward, level + 1, nullptr);
    }
};

// Skip list class
class SkipList {
public:
    SkipList() {
        // Initialize head and tail sentinel nodes
        head = new Node(MAX_LEVEL, INT_MIN); // Sentinel node with minimum value
        tail = new Node(MAX_LEVEL, INT_MAX); // Sentinel node with maximum value

        // Connect all levels of head to tail initially
        for (int i = 0; i <= MAX_LEVEL; ++i) {
            head->forward[i] = tail;
        }

        srand(time(nullptr));
    }

    // Insert value into the skip list
    void insert(int ptr) {
        Node* current = head;
        Node* update[MAX_LEVEL + 1];
        fill_n(update, MAX_LEVEL + 1, nullptr);

        // Traverse levels from top to bottom
        for (int i = MAX_LEVEL; i >= 0; --i) {
            while (current->forward[i]->value < ptr) {
                current = current->forward[i];
            }
            update[i] = current;
        }

        current = current->forward[0];
        if (current->value != ptr) {
            int level = randomLevel();
            Node* newNode = new Node(level, ptr);

            // Insert the new node at appropriate levels
            for (int i = 0; i < level; ++i) {
                newNode->forward[i] = update[i]->forward[i];
                update[i]->forward[i] = newNode;
            }
        }
    }

    // Delete value from the skip list
    void remove(int value) {
        Node* current = head;
        Node* update[MAX_LEVEL + 1];
        fill_n(update, MAX_LEVEL + 1, nullptr);

        // Traverse levels from top to bottom
        for (int i = MAX_LEVEL; i >= 0; --i) {
            while (current->forward[i]->value < value) {
                current = current->forward[i];
            }
            update[i] = current;
        }

        current = current->forward[0];
        if (current->value == value) {
            // Remove the node from each level it exists
            for (int i = 0; i <= MAX_LEVEL; ++i) {
                if (update[i]->forward[i] != current) {
                    break;
                }
                update[i]->forward[i] = current->forward[i];
            }
            delete current;
        }
    }

    // Search for value in the skip list
    bool search(int value) {
        Node* current = head;

        // Traverse levels from top to bottom
        for (int i = MAX_LEVEL; i >= 0; --i) {
            while (current->forward[i]->value < value) {
                current = current->forward[i];
            }
        }

        current = current->forward[0];
        return current->value == value;
    }

    // Display the skip list
    void display() {
        for (int i = MAX_LEVEL; i >= 0; --i) {
            Node* current = head->forward[i];
            cout << "Level " << i << ": ";
            while (current != tail) {
                cout << current->value << " ";
                current = current->forward[i];
            }
            cout << endl;
        }
    }

private:
    Node* head;
    Node* tail;

    // Generate a random level for a new node
    int randomLevel() {
        int level = 1;
        while (rand() % 2 == 0 && level <=MAX_LEVEL) {
            level++;
        }
        return level;
    }
};

int main() {
    SkipList skipList;

    skipList.insert(3);
    skipList.insert(20);
    skipList.insert(10);
    skipList.insert(7);
    skipList.insert(50);
    skipList.insert(9);
    skipList.insert(11);
    skipList.insert(11);
    skipList.insert(80);
      skipList.insert(15);
        skipList.insert(35);
    skipList.insert(90);

    cout << "Skip List Contents:" << endl;
    skipList.display();

    cout << "Search 15: " << (skipList.search(15) ? "Found" : "Not Found") << endl;

    return 0;
}
