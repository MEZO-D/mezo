﻿using System;

namespace WindowsFormsApp1
{
    internal class TestClassAttribute : Attribute
    {
    }
}