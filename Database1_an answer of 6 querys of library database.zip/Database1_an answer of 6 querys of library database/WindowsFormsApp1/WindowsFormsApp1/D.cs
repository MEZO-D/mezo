﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class D : Form
    {
        public D()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            GUEST L = new GUEST();
            L.Show();
        }

        private void D_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.AUTHOR' table. You can move, or remove it, as needed.
            this.aUTHORTableAdapter.Fill(this.dataSet1.AUTHOR);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connstring = @"Data Source=DESKTOP-VTFTMFC\SQLLL;Initial Catalog=Library;Integrated Security=True";
            SqlConnection con = new SqlConnection(connstring);
            con.Open();
            string querry = "select a.a_id,a.a_name from author as a, book as b ,UPLOADED_BY as u where a.A_ID = u.A_ID and b.ID = u.ID group by a.a_id,a.a_name having sum(NUMBER_OF_UPLOADS) is null or sum(NUMBER_OF_UPLOADS)= 0 ";
            SqlCommand cd = new SqlCommand(querry, con);
            var reader = cd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Load(reader);
            dataGridView1.DataSource = tbl;
            con.Close();
        }
    }
}
