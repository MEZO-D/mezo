﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class A : Form
    {
        public A()
        {
            InitializeComponent();
        }

        private void A_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.BOOK_COPIES' table. You can move, or remove it, as needed.
            this.bOOK_COPIESTableAdapter.Fill(this.dataSet1.BOOK_COPIES);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            GUEST L = new GUEST();
            L.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connstring = @"Data Source=DESKTOP-VTFTMFC\SQLLL;Initial Catalog=Library;Integrated Security=True";
            SqlConnection con = new SqlConnection(connstring);
            con.Open();
            
            string querry = " SELECT top 2 book_copies.copy_ID ,BOOK_COPIES.TITLE_ , count(buy.r_id) as Total_buyers FROM buy inner join book_copies on buy.copy_ID = book_copies.copy_ID group by book_copies.copy_ID,BOOK_COPIES.TITLE_ ORDER BY Total_buyers desc ";
            SqlCommand cd = new SqlCommand(querry, con);
            var reader = cd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Load(reader);
            dataGridView1.DataSource = tbl;
            con.Close();
        }
    }
}
