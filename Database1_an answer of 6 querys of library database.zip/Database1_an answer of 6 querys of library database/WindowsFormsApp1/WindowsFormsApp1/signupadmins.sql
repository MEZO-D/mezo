alter proc adminn
@AD_ID int ,
@AD_NAME varchar(50),
@AD_EMAIL varchar(50),
@USER_NAME_ADMIN varchar(50),
@PASSWORD_ADMIN varchar(50)
as
Insert into ADMIN (AD_ID,AD_NAME,AD_EMAIL,USER_NAME_ADMIN,PASSWORD_ADMIN)
values (@AD_ID,@AD_NAME,@AD_EMAIL,@USER_NAME_ADMIN,@PASSWORD_ADMIN)