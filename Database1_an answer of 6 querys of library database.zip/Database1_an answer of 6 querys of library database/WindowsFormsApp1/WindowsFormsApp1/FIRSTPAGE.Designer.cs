﻿namespace WindowsFormsApp1
{
    partial class FIRSTPAGE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.BTN_SIGNIN = new System.Windows.Forms.Button();
            this.BTN_SIGNUP = new System.Windows.Forms.Button();
            this.BTN_GUEST = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Desktop;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(248, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(717, 91);
            this.label1.TabIndex = 0;
            this.label1.Text = "Librarothica Library";
            // 
            // BTN_SIGNIN
            // 
            this.BTN_SIGNIN.BackColor = System.Drawing.Color.Black;
            this.BTN_SIGNIN.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_SIGNIN.ForeColor = System.Drawing.SystemColors.Control;
            this.BTN_SIGNIN.Location = new System.Drawing.Point(63, 127);
            this.BTN_SIGNIN.Name = "BTN_SIGNIN";
            this.BTN_SIGNIN.Size = new System.Drawing.Size(202, 71);
            this.BTN_SIGNIN.TabIndex = 1;
            this.BTN_SIGNIN.Text = "SIGN IN";
            this.BTN_SIGNIN.UseVisualStyleBackColor = false;
            this.BTN_SIGNIN.Click += new System.EventHandler(this.BTN_SIGNIN_Click);
            // 
            // BTN_SIGNUP
            // 
            this.BTN_SIGNUP.BackColor = System.Drawing.Color.Black;
            this.BTN_SIGNUP.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_SIGNUP.ForeColor = System.Drawing.SystemColors.Control;
            this.BTN_SIGNUP.Location = new System.Drawing.Point(986, 127);
            this.BTN_SIGNUP.Name = "BTN_SIGNUP";
            this.BTN_SIGNUP.Size = new System.Drawing.Size(197, 71);
            this.BTN_SIGNUP.TabIndex = 2;
            this.BTN_SIGNUP.Text = "SIGN UP";
            this.BTN_SIGNUP.UseVisualStyleBackColor = false;
            this.BTN_SIGNUP.Click += new System.EventHandler(this.BTN_SIGNUP_Click);
            // 
            // BTN_GUEST
            // 
            this.BTN_GUEST.BackColor = System.Drawing.Color.Black;
            this.BTN_GUEST.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_GUEST.ForeColor = System.Drawing.SystemColors.Control;
            this.BTN_GUEST.Location = new System.Drawing.Point(463, 237);
            this.BTN_GUEST.Name = "BTN_GUEST";
            this.BTN_GUEST.Size = new System.Drawing.Size(303, 85);
            this.BTN_GUEST.TabIndex = 5;
            this.BTN_GUEST.Tag = "";
            this.BTN_GUEST.Text = "ENTER AS A GUEST";
            this.BTN_GUEST.UseVisualStyleBackColor = false;
            this.BTN_GUEST.Click += new System.EventHandler(this.BTN_GUEST_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(251, 436);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(744, 41);
            this.button1.TabIndex = 6;
            this.button1.Text = "EXIT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FIRSTPAGE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1272, 503);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BTN_GUEST);
            this.Controls.Add(this.BTN_SIGNUP);
            this.Controls.Add(this.BTN_SIGNIN);
            this.Controls.Add(this.label1);
            this.Name = "FIRSTPAGE";
            this.Text = "LIBRARY";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BTN_SIGNIN;
        private System.Windows.Forms.Button BTN_SIGNUP;
        private System.Windows.Forms.Button BTN_GUEST;
        private System.Windows.Forms.Button button1;
    }
}

