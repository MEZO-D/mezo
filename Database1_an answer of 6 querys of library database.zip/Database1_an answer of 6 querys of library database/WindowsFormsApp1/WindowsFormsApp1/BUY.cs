﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class BUY : Form
    {
        public BUY()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "")
            {
                MessageBox.Show("PLEASE FILL ALL DATA AND IF YOU AN ADMIN PUT IN MOBILE LETTER 0 ");
            }
            else
            {
                this.Hide();
                BUYNOW M = new BUYNOW();
                M.Show();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            READER A = new READER();
            A.Show();
         
        }
    }
}
