﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class SIGNINPAGE : Form
    {
        public SIGNINPAGE()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-VTFTMFC\SQLLL;Initial Catalog=Library;Integrated Security=True");
       
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FIRSTPAGE N = new FIRSTPAGE();
            N.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(ADMIN.Checked)
            {
                string username, user_password;
                username = textBox1.Text;
                user_password = textBox2.Text;
                try
                {
                    string querry = "SELECT* FROM ADMIN WHERE USER_NAME_ADMIN = '" + textBox1.Text + "'AND PASSWORD_ADMIN ='" + textBox2.Text + "'";
                    SqlDataAdapter nna = new SqlDataAdapter(querry, conn);
                    DataTable vva = new DataTable();
                    nna.Fill(vva);
                    if (vva.Rows.Count > 0)
                    {
                        username = textBox1.Text;
                        user_password = textBox2.Text;

                        ADMIN F = new ADMIN();
                        F.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("WRONG USERNAME OF PASSWORD", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        clear();
                        textBox1.Focus();
                    }
                }
                catch { MessageBox.Show("ERROR"); }
                finally { conn.Close(); }

            }

          else if (AUTHOR.Checked)
            {
                string username, user_password;
                username = textBox1.Text;
                user_password = textBox2.Text;
                try
                {
                    string querry = "SELECT * FROM AUTHOR WHERE USER_NAME_AUTHOR = '" + textBox1.Text + "'AND PASSWORD__AUTHOR ='" + textBox2.Text + "'";
                    SqlDataAdapter nna = new SqlDataAdapter(querry, conn);
                    DataTable vva = new DataTable();
                    nna.Fill(vva);
                    if (vva.Rows.Count > 0)
                    {
                        username = textBox1.Text;
                        user_password = textBox2.Text;

                        AUTHOR F = new AUTHOR();
                        F.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("WRONG USERNAME OF PASSWORD", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        clear();
                        textBox1.Focus();
                    }
                }
                catch { MessageBox.Show("ERROR"); }
                finally { conn.Close(); }

            }
            else if (READERZ.Checked)
            {
                string username, user_password;
                username = textBox1.Text;
                user_password = textBox2.Text;
                try
                {
                    string querry = "SELECT* FROM READER_BUYER WHERE USER_NAME_BUYER = '" + textBox1.Text + "'AND PASSWORD_BUYER ='" + textBox2.Text + "'";
                    SqlDataAdapter nna = new SqlDataAdapter(querry, conn);
                    DataTable vva = new DataTable();
                    nna.Fill(vva);
                    if (vva.Rows.Count > 0)
                    {
                        username = textBox1.Text;
                        user_password = textBox2.Text;

                       READER F = new READER();
                        F.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("WRONG USERNAME OF PASSWORD", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        clear();
                        textBox1.Focus();
                    }
                }
                catch { MessageBox.Show("ERROR"); }
                finally { conn.Close(); }

            }
            else { MessageBox.Show( "PLEASE CHOOSE TYPE OF LOGIN"  , "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        void clear()
        {
            textBox1.Text = textBox2.Text = " ";

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
   
    }
}
