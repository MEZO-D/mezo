﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class F : Form
    {
        public F()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.READER_BUYER' table. You can move, or remove it, as needed.
            this.rEADER_BUYERTableAdapter.Fill(this.dataSet1.READER_BUYER);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
           GUEST L = new GUEST();
            L.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connstring = @"Data Source=DESKTOP-VTFTMFC\SQLLL;Initial Catalog=Library;Integrated Security=True";
            SqlConnection con = new SqlConnection(connstring);
            con.Open();
            string querry = " select r.r_id,r.r_name,r.r_mobile ,count(b.R_ID) as total_books from READER_BUYER as r, BUY as b,BOOK_COPIES where r.R_ID = b.R_ID and BOOK_COPIES.COPY_ID = b.COPY_ID group by r.r_id,r.r_name,r.r_mobile order by r.r_id asc";
            SqlCommand cd = new SqlCommand(querry, con);
            var reader = cd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Load(reader);
            dataGridView1.DataSource = tbl;
            con.Close();
        }
    }
}
