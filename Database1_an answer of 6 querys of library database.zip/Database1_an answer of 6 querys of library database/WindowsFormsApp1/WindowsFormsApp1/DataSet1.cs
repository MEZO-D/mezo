﻿namespace WindowsFormsApp1
{


    partial class DataSet1
    {
        partial class DataTable3DataTable
        {
        }
    }
}

namespace WindowsFormsApp1.DataSet1TableAdapters {
    
    
    public partial class QueriesTableAdapter {
        
    }
}
