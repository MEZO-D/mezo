﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class AUTHOR : Form
    {
        public AUTHOR()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            SIGNINPAGE F = new SIGNINPAGE();
            F.Show();

        }

        private void AUTHOR_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'libraryDataSet.BOOK' table. You can move, or remove it, as needed.
            this.bOOKTableAdapter.Fill(this.libraryDataSet.BOOK);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-VTFTMFC\\SQLLL;Initial Catalog=Library;Integrated Security=True");
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            conn.Open();
            cmd.CommandText = "INSERT INTO BOOK VALUES('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "') ;";
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.bOOKTableAdapter.Fill(this.libraryDataSet.BOOK);
        }
    }
}
