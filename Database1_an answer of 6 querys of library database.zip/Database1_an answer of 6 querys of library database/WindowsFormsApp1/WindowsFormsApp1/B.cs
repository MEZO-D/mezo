﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class B : Form
    {
        public B()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            GUEST L = new GUEST();
            L.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connstring = @"Data Source=DESKTOP-VTFTMFC\SQLLL;Initial Catalog=Library;Integrated Security=True";
            SqlConnection con = new SqlConnection(connstring);
            con.Open();
            string querry = " select distinct BOOK_COPIES.TITLE_  ,BOOK_COPIES.COPY_ID from BUY, BOOK_COPIES, READER_BUYER as r where BOOK_COPIES.COPY_ID = buy.COPY_ID or BOOK_COPIES.COPY_ID != buy.COPY_ID and r.R_ID = buy.R_ID except select distinct BOOK_COPIES.TITLE_  ,BOOK_COPIES.COPY_ID from BUY , BOOK_COPIES ,READER_BUYER as r where BOOK_COPIES.COPY_ID = buy.COPY_ID and r.R_ID = buy.R_ID and  (BUY.BUY_DATE between '2022-05-1 00:00:00.000' and '2022-05-30 00:00:00.000') ";
            SqlCommand cd = new SqlCommand(querry, con);
            var reader = cd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Load(reader);
            dataGridView1.DataSource = tbl;
            con.Close();
        }
    }
}
