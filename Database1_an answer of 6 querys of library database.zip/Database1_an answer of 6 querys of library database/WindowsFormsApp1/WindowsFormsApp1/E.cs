﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class E : Form
    {
        public E()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            GUEST L = new GUEST();
            L.Show();
        }

        private void E_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.CATEGORY' table. You can move, or remove it, as needed.
            this.cATEGORYTableAdapter.Fill(this.dataSet1.CATEGORY);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connstring = @"Data Source=DESKTOP-VTFTMFC\SQLLL;Initial Catalog=Library;Integrated Security=True";
            SqlConnection con = new SqlConnection(connstring);
            con.Open();
            string querry = "select  category_name from category, book_copies, include where category.category_id = include.category_id and book_copies.copy_id = include.copy_id group by category_name order by sum(book_copies.B_NUM_COPIES) asc ";
            SqlCommand cd = new SqlCommand(querry, con);
            var reader = cd.ExecuteReader();
            DataTable tbl = new DataTable();
            tbl.Load(reader);
            dataGridView1.DataSource = tbl;
            con.Close();
        }
    }
}
