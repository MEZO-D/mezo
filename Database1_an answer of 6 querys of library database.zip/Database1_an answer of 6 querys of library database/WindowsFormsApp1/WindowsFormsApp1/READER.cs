﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class READER : Form
    {
        public READER()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            SIGNINPAGE F = new SIGNINPAGE();
            F.Show();

        }

        private void READER_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.DataTable1' table. You can move, or remove it, as needed.
            this.dataTable1TableAdapter.Fill(this.dataSet1.DataTable1);

        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            BUY M = new BUY();
            M.Show();
                
        }
    }
}
