﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class ADMIN : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-VTFTMFC\\SQLLL;Initial Catalog=Library;Integrated Security=True");

        public ADMIN()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            SIGNINPAGE F = new SIGNINPAGE();
            F.Show();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-VTFTMFC\\SQLLL;Initial Catalog=Library;Integrated Security=True");
            conn.Open();
                String ID = textBox1.Text;
                String NAME = textBox2.Text;
                String AUTHOR = textBox3.Text;
            String QUERY = "UPDATE BOOK SET NAME = '"+NAME+ "' , AUTHOR = '"+AUTHOR+"' WHERE ID= "+ID ;
            SqlCommand cmd = new SqlCommand(QUERY, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("DATA HAS BEEN UPDATED");
        }
            private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void ADMIN_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'libraryDataSet.BOOK' table. You can move, or remove it, as needed.
            this.bOOKTableAdapter.Fill(this.libraryDataSet.BOOK);
            // TODO: This line of code loads data into the 'dataSet1.DataTable3' table. You can move, or remove it, as needed.
            this.dataTable3TableAdapter.Fill(this.dataSet1.DataTable3);

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

      

        private void button5_Click(object sender, EventArgs e)
        {
            this.bOOKTableAdapter.Fill(this.libraryDataSet.BOOK);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-VTFTMFC\\SQLLL;Initial Catalog=Library;Integrated Security=True");
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn  ;
            conn .Open() ;
            cmd.CommandText = "INSERT INTO BOOK VALUES('"+textBox1.Text  +"','"+textBox2.Text+"','"+textBox3.Text+"') ;";
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
