﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class SIGNUPPAGE : Form
    {
        string connstring = @"Data Source=DESKTOP-VTFTMFC\SQLLL;Initial Catalog=Library;Integrated Security=True";

        public SIGNUPPAGE()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FIRSTPAGE N = new FIRSTPAGE();
            N.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void READER_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void AUTHOR_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ADMIN.Checked)
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "")
                {
                    MessageBox.Show("PLEASE FILL ALL DATA AND IF YOU AN ADMIN PUT IN MOBILE LETTER 0 ");
                }
                else

                {
                    if (textBox7.Text == "91283" || textBox7.Text == "91500" || textBox7.Text == "91700")
                    {
                        using (SqlConnection sqlcon = new SqlConnection(connstring))
                        {
                            try
                            {

                                sqlcon.Open();
                                SqlCommand sqlcmd = new SqlCommand("adminn", sqlcon);
                                sqlcmd.CommandType = CommandType.StoredProcedure;
                                sqlcmd.Parameters.AddWithValue("@AD_ID", textBox1.Text.Trim());
                                sqlcmd.Parameters.AddWithValue("@AD_NAME", textBox4.Text.Trim());
                                sqlcmd.Parameters.AddWithValue("@AD_EMAIL", textBox2.Text.Trim());
                                sqlcmd.Parameters.AddWithValue("@USER_NAME_ADMIN", textBox3.Text.Trim());
                                sqlcmd.Parameters.AddWithValue("@PASSWORD_ADMIN", textBox5.Text.Trim());
                                sqlcmd.ExecuteNonQuery();

                                MessageBox.Show("YOU HAVE BEEN REGESTIED SUCESSFULLY ");
                                clear();
                            }
                            catch { MessageBox.Show("Please enter the data as follows --> ID:INTEGERS ONLY "); }
                        }
                    }
                    else { MessageBox.Show("SORRY YOUR CODE ARE WRONG IF YOU WANT TO BE ADMIN YOU MUST HAVE A CODE FROM THE REAL ADMINS :)");clear(); }
                }

                
            
            }

            else if (AUTHOR.Checked)
            {
                if (textBox1.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox2.Text == "" || textBox6.Text == "" || textBox5.Text == ""|| textBox7.Text == "")
                {
                    MessageBox.Show("PLEASE FILL ALL DATA AND IF YOU AN AUTHOR PUT IN EMAIL AND MOBILE LETTER 0");
                }
                else
                {
                    using (SqlConnection sqlcon = new SqlConnection(connstring))
                    {
                        try
                        {

                            sqlcon.Open();
                            SqlCommand sqlcmd = new SqlCommand("auth", sqlcon);
                            sqlcmd.CommandType = CommandType.StoredProcedure;
                            sqlcmd.Parameters.AddWithValue("@A_ID", textBox1.Text.Trim());
                            sqlcmd.Parameters.AddWithValue("@A_NAME", textBox4.Text.Trim());
                            sqlcmd.Parameters.AddWithValue("@USER_NAME_AUTHOR", textBox3.Text.Trim());
                            sqlcmd.Parameters.AddWithValue("@PASSWORD__AUTHOR", textBox5.Text.Trim());
                            sqlcmd.ExecuteNonQuery();

                            MessageBox.Show("YOU HAVE BEEN REGESTIED SUCESSFULLY ");
                            clear();
                        }
                        catch { MessageBox.Show("Please enter the data as follows --> ID:INTEGERS ONLY "); }
                    }
                }

            }
            else if (READER.Checked)
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == ""|| textBox7.Text == "")
                {
                    MessageBox.Show("PLEASE FILL ALL DATA AND IF YOU AN READER/STUDENT PUT IN EMAIL LETTER 0 ");
                }
                else
                {
                    using (SqlConnection sqlcon = new SqlConnection(connstring))
                    {
                        try
                        {
                            sqlcon.Open();
                            SqlCommand sqlcmd = new SqlCommand("red", sqlcon);
                            sqlcmd.CommandType = CommandType.StoredProcedure;
                            sqlcmd.Parameters.AddWithValue("@R_ID", textBox1.Text.Trim());
                            sqlcmd.Parameters.AddWithValue("@R_NAME", textBox4.Text.Trim());
                            sqlcmd.Parameters.AddWithValue("@R_MOBILE", textBox6.Text.Trim());
                            sqlcmd.Parameters.AddWithValue("@USER_NAME_BUYER", textBox3.Text.Trim());
                            sqlcmd.Parameters.AddWithValue("@PASSWORD_BUYER", textBox5.Text.Trim());
                            sqlcmd.ExecuteNonQuery();

                            MessageBox.Show("YOU HAVE BEEN REGESTIED SUCESSFULLY ");
                            clear();
                        }
                        catch { MessageBox.Show("Please enter the data as follows --> (ID:INTEGERS ONLY  , MOBILE:INTEGERS ONLY )"); }
                    }
                }
            }
            else { MessageBox.Show("PLEASE CHOOSE WHAT IS THE TYPE OF SIGNUP "); }

        }
        void clear()
        {
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox6.Text= textBox7.Text = textBox5.Text = " ";

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
