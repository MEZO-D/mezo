﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class avl : Form
    {
        public avl()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            GUEST L = new GUEST();
            L.Show();
        }

        private void avl_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.DataTable1' table. You can move, or remove it, as needed.
            this.dataTable1TableAdapter.Fill(this.dataSet1.DataTable1);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            SIGNINPAGE F = new SIGNINPAGE();
            F.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            SIGNUPPAGE X = new SIGNUPPAGE();
            X.Show();
        }
    }
}
