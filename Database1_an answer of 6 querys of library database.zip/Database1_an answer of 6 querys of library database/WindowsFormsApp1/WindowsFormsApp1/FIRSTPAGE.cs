﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FIRSTPAGE : Form
    {
        public FIRSTPAGE()
        {
            InitializeComponent();
        }

        private void BTN_SIGNIN_Click(object sender, EventArgs e)
        {   
            this.Hide();
            SIGNINPAGE F = new SIGNINPAGE();
            F.Show();
          
            
        }

        private void BTN_SIGNUP_Click(object sender, EventArgs e)
        {
            this.Hide();
            SIGNUPPAGE X = new SIGNUPPAGE();
            X.Show();
        }

        private void BTN_INSTRUCTIONS_Click(object sender, EventArgs e)
        {
          
        }

        private void BTN_GUEST_Click(object sender, EventArgs e)
        {
            this.Hide();
            GUEST A = new GUEST();
            A.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
