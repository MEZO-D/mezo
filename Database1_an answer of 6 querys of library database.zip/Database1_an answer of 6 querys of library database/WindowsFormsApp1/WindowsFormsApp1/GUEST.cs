﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class GUEST : Form
    {
        public GUEST()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FIRSTPAGE N = new FIRSTPAGE();
            N.Show();
        }

        private void BTN_SIGNIN_Click(object sender, EventArgs e)
        {
            this.Hide();
            F N = new F();
            N.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            A N = new A();
            N.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            D N = new D();
            N.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            E N = new E();
            N.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            B N = new B();
            N.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            C N = new C();
            N.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            avl x = new avl();
            x.Show();


        }
    }
}
