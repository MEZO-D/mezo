/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2012                    */
/* Created on:     5/29/2022 6:32:25 PM                         */
/*==============================================================*/


if exists (select 1
            from  sysobjects
           where  id = object_id('ADMIN')
            and   type = 'U')
   drop table ADMIN
go

if exists (select 1
            from  sysobjects
           where  id = object_id('AUTHOR')
            and   type = 'U')
   drop table AUTHOR
go

if exists (select 1
            from  sysobjects
           where  id = object_id('BOOK')
            and   type = 'U')
   drop table BOOK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('BOOK_COPIES')
            and   type = 'U')
   drop table BOOK_COPIES
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('BUY')
            and   name  = 'RELATIONSHIP_9_FK'
            and   indid > 0
            and   indid < 255)
   drop index BUY.RELATIONSHIP_9_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('BUY')
            and   name  = 'RELATIONSHIP_8_FK'
            and   indid > 0
            and   indid < 255)
   drop index BUY.RELATIONSHIP_8_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('BUY')
            and   type = 'U')
   drop table BUY
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CATEGORY')
            and   type = 'U')
   drop table CATEGORY
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONTROLLED')
            and   name  = 'CONTROLLED2_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONTROLLED.CONTROLLED2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONTROLLED')
            and   name  = 'CONTROLLED_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONTROLLED.CONTROLLED_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CONTROLLED')
            and   type = 'U')
   drop table CONTROLLED
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONTROLLER')
            and   name  = 'CONTROLLER2_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONTROLLER.CONTROLLER2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONTROLLER')
            and   name  = 'CONTROLLER_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONTROLLER.CONTROLLER_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CONTROLLER')
            and   type = 'U')
   drop table CONTROLLER
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('COPIES')
            and   name  = 'COPIES2_FK'
            and   indid > 0
            and   indid < 255)
   drop index COPIES.COPIES2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('COPIES')
            and   name  = 'COPIES_FK'
            and   indid > 0
            and   indid < 255)
   drop index COPIES.COPIES_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('COPIES')
            and   type = 'U')
   drop table COPIES
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('INCLUDE')
            and   name  = 'INCLUDE2_FK'
            and   indid > 0
            and   indid < 255)
   drop index INCLUDE.INCLUDE2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('INCLUDE')
            and   name  = 'INCLUDE_FK'
            and   indid > 0
            and   indid < 255)
   drop index INCLUDE.INCLUDE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('INCLUDE')
            and   type = 'U')
   drop table INCLUDE
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('LOGIN')
            and   name  = 'LOG_FK'
            and   indid > 0
            and   indid < 255)
   drop index LOGIN.LOG_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('LOGIN')
            and   type = 'U')
   drop table LOGIN
go

if exists (select 1
            from  sysobjects
           where  id = object_id('READER_BUYER')
            and   type = 'U')
   drop table READER_BUYER
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('UPLOADED_BY')
            and   name  = 'RELATIONSHIP_12_FK'
            and   indid > 0
            and   indid < 255)
   drop index UPLOADED_BY.RELATIONSHIP_12_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('UPLOADED_BY')
            and   name  = 'RELATIONSHIP_11_FK'
            and   indid > 0
            and   indid < 255)
   drop index UPLOADED_BY.RELATIONSHIP_11_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('UPLOADED_BY')
            and   type = 'U')
   drop table UPLOADED_BY
go

/*==============================================================*/
/* Table: ADMIN                                                 */
/*==============================================================*/
create table ADMIN (
   AD_ID                numeric(15)          not null,
   AD_NAME              varchar(30)          not null,
   AD_EMAIL             varchar(30)          not null,
   USER_NAME_ADMIN      varchar(40)          not null,
   PASSWORD_ADMIN       varchar(40)          not null,
   constraint PK_ADMIN primary key nonclustered (AD_ID, USER_NAME_ADMIN)
)
go

/*==============================================================*/
/* Table: AUTHOR                                                */
/*==============================================================*/
create table AUTHOR (
   A_ID                 numeric(15)          not null,
   A_NAME               varchar(30)          not null,
   USER_NAME_AUTHOR     varchar(40)          not null,
   PASSWORD__AUTHOR     varchar(20)          not null,
   constraint PK_AUTHOR primary key nonclustered (A_ID, USER_NAME_AUTHOR)
)
go

/*==============================================================*/
/* Table: BOOK                                                  */
/*==============================================================*/
create table BOOK (
   ID                   numeric(15)          not null,
   NAME                 varchar(30)          not null,
   AUTHOR               varchar(30)          not null,
   constraint PK_BOOK primary key nonclustered (ID)
)
go

/*==============================================================*/
/* Table: BOOK_COPIES                                           */
/*==============================================================*/
create table BOOK_COPIES (
   COPY_ID              varchar(30)          not null,
   TITLE_               char(30)             not null,
   B_NUM_COPIES         numeric(5)           not null,
   B_AVAILABILITY       varchar(20)          not null,
   constraint PK_BOOK_COPIES primary key nonclustered (COPY_ID)
)
go

/*==============================================================*/
/* Table: BUY                                                   */
/*==============================================================*/
create table BUY (
   COPY_ID              varchar(30)          not null,
   R_ID                 numeric(15)          not null,
   USER_NAME_BUYER      varchar(40)          not null,
   BUY_DATE             datetime             null,
   constraint PK_BUY primary key (COPY_ID, R_ID, USER_NAME_BUYER)
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_8_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_8_FK on BUY (
COPY_ID ASC
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_9_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_9_FK on BUY (
R_ID ASC,
USER_NAME_BUYER ASC
)
go

/*==============================================================*/
/* Table: CATEGORY                                              */
/*==============================================================*/
create table CATEGORY (
   CATEGORY_ID          numeric(3)           not null,
   CATEGORY_NAME        char(30)             not null,
   constraint PK_CATEGORY primary key nonclustered (CATEGORY_ID)
)
go

/*==============================================================*/
/* Table: CONTROLLED                                            */
/*==============================================================*/
create table CONTROLLED (
   R_ID                 numeric(15)          not null,
   USER_NAME_BUYER      varchar(40)          not null,
   L_USER_NAME          varchar(40)          not null,
   constraint PK_CONTROLLED primary key (R_ID, USER_NAME_BUYER, L_USER_NAME)
)
go

/*==============================================================*/
/* Index: CONTROLLED_FK                                         */
/*==============================================================*/
create index CONTROLLED_FK on CONTROLLED (
R_ID ASC,
USER_NAME_BUYER ASC
)
go

/*==============================================================*/
/* Index: CONTROLLED2_FK                                        */
/*==============================================================*/
create index CONTROLLED2_FK on CONTROLLED (
L_USER_NAME ASC
)
go

/*==============================================================*/
/* Table: CONTROLLER                                            */
/*==============================================================*/
create table CONTROLLER (
   AD_ID                numeric(15)          not null,
   USER_NAME_ADMIN      varchar(40)          not null,
   L_USER_NAME          varchar(40)          not null,
   constraint PK_CONTROLLER primary key (AD_ID, USER_NAME_ADMIN, L_USER_NAME)
)
go

/*==============================================================*/
/* Index: CONTROLLER_FK                                         */
/*==============================================================*/
create index CONTROLLER_FK on CONTROLLER (
AD_ID ASC,
USER_NAME_ADMIN ASC
)
go

/*==============================================================*/
/* Index: CONTROLLER2_FK                                        */
/*==============================================================*/
create index CONTROLLER2_FK on CONTROLLER (
L_USER_NAME ASC
)
go

/*==============================================================*/
/* Table: COPIES                                                */
/*==============================================================*/
create table COPIES (
   ID                   numeric(15)          not null,
   COPY_ID              varchar(30)          not null,
   constraint PK_COPIES primary key (ID, COPY_ID)
)
go

/*==============================================================*/
/* Index: COPIES_FK                                             */
/*==============================================================*/
create index COPIES_FK on COPIES (
ID ASC
)
go

/*==============================================================*/
/* Index: COPIES2_FK                                            */
/*==============================================================*/
create index COPIES2_FK on COPIES (
COPY_ID ASC
)
go

/*==============================================================*/
/* Table: INCLUDE                                               */
/*==============================================================*/
create table INCLUDE (
   CATEGORY_ID          numeric(3)           not null,
   COPY_ID              varchar(30)          not null,
   constraint PK_INCLUDE primary key (CATEGORY_ID, COPY_ID)
)
go

/*==============================================================*/
/* Index: INCLUDE_FK                                            */
/*==============================================================*/
create index INCLUDE_FK on INCLUDE (
CATEGORY_ID ASC
)
go

/*==============================================================*/
/* Index: INCLUDE2_FK                                           */
/*==============================================================*/
create index INCLUDE2_FK on INCLUDE (
COPY_ID ASC
)
go

/*==============================================================*/
/* Table: LOGIN                                                 */
/*==============================================================*/
create table LOGIN (
   L_PASSWORD           varchar(18)          not null,
   L_USER_NAME          varchar(40)          not null,
   A_ID                 numeric(15)          null,
   USER_NAME_AUTHOR     varchar(40)          null,
   constraint PK_LOGIN primary key nonclustered (L_USER_NAME)
)
go

/*==============================================================*/
/* Index: LOG_FK                                                */
/*==============================================================*/
create index LOG_FK on LOGIN (
A_ID ASC,
USER_NAME_AUTHOR ASC
)
go

/*==============================================================*/
/* Table: READER_BUYER                                          */
/*==============================================================*/
create table READER_BUYER (
   R_ID                 numeric(15)          not null,
   R_NAME               varchar(30)          not null,
   R_MOBILE             numeric(15)          null,
   USER_NAME_BUYER      varchar(40)          not null,
   PASSWORD_BUYER       varchar(18)          not null,
   constraint PK_READER_BUYER primary key nonclustered (R_ID, USER_NAME_BUYER)
)
go

/*==============================================================*/
/* Table: UPLOADED_BY                                           */
/*==============================================================*/
create table UPLOADED_BY (
   ID                   numeric(15)          not null,
   A_ID                 numeric(15)          not null,
   USER_NAME_AUTHOR     varchar(40)          not null,
   NUMBER_OF_UPLOADS    numeric              null,
   constraint PK_UPLOADED_BY primary key (ID, A_ID, USER_NAME_AUTHOR)
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_11_FK                                    */
/*==============================================================*/
create index RELATIONSHIP_11_FK on UPLOADED_BY (
ID ASC
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_12_FK                                    */
/*==============================================================*/
create index RELATIONSHIP_12_FK on UPLOADED_BY (
A_ID ASC,
USER_NAME_AUTHOR ASC
)
go

