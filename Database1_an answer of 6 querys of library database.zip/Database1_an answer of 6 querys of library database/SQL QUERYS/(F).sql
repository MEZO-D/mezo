select r.r_id,r.r_name,r.r_mobile ,count(b.R_ID) as total_books
from READER_BUYER as r, BUY as b,BOOK_COPIES
where r.R_ID=b.R_ID and BOOK_COPIES.COPY_ID=b.COPY_ID
group by r.r_id,r.r_name,r.r_mobile
order by  r.r_id asc 
