select count (s.a_id) as number_of_author
from (select AUTHOR.A_ID,AUTHOR.A_NAME
from BOOK , AUTHOR, BUY,UPLOADED_BY as u , BOOK_COPIES
where  not exists( select *
from BUY
where u.A_ID=author.A_ID and book.ID=u.ID and book.ID=BOOK_COPIES.COPY_ID and buy.COPY_ID=BOOK_COPIES.COPY_ID )
except 
select AUTHOR.A_ID,AUTHOR.A_NAME
from BOOK , AUTHOR, BUY,UPLOADED_BY as u , BOOK_COPIES
where   exists( select *
from BUY
where  u.A_ID=author.A_ID and book.ID=u.ID and book.ID=BOOK_COPIES.COPY_ID and buy.COPY_ID=BOOK_COPIES.COPY_ID and 
(buy.BUY_DATE  between '2022-05-1 00:00:00.000' and '2022-05-30 00:00:00.000'))) as s
