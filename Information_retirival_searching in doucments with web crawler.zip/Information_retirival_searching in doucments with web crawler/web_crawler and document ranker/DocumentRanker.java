import java.io.*;
import java.util.*;

public class DocumentRanker {
    private Map<String, List<String>> invertedIndex;
    private List<String> documentList;
    private Map<String, Integer> documentFrequencies;

    public DocumentRanker() {
        invertedIndex = new HashMap<>();
        documentList = new ArrayList<>();
        documentFrequencies = new HashMap<>();
    }

    public void buildInvertedIndex(List<String> documents) throws IOException {
        for (String document : documents) {
            BufferedReader reader = new BufferedReader(new FileReader(document));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] terms = line.split("\\W+");
                for (String term : terms) {
                    term = term.toLowerCase();
                    if (!invertedIndex.containsKey(term)) {
                        invertedIndex.put(term, new ArrayList<>());
                        documentFrequencies.put(term, 0);
                    }
                    if (!invertedIndex.get(term).contains(document)) {
                        invertedIndex.get(term).add(document);
                        documentFrequencies.put(term, documentFrequencies.get(term) + 1);
                    }
                }
            }
            reader.close();
            documentList.add(document);
        }
    }

    public Map<String, Double> calculateDocumentSimilarities(String query) {
        Map<String, Double> documentSimilarities = new HashMap<>();
        String[] queryTerms = query.split("\\W+");
        Map<String, Integer> queryVector = new HashMap<>();
        int queryLength = 0;

        for (String term : queryTerms) {
            term = term.toLowerCase();
            if (!queryVector.containsKey(term)) {
                queryVector.put(term, 0);
            }
            queryVector.put(term, queryVector.get(term) + 1);
            queryLength++;
        }

        for (String document : documentList) {
            double dotProduct = 0;
            double documentLength = 0;
            Map<String, Integer> documentVector = new HashMap<>();
            BufferedReader reader;
            try {
                reader = new BufferedReader(new FileReader(document));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] terms = line.split("\\W+");
                    for (String term : terms) {
                        term = term.toLowerCase();
                        if (!documentVector.containsKey(term)) {
                            documentVector.put(term, 0);
                        }
                        documentVector.put(term, documentVector.get(term) + 1);
                    }
                }
                reader.close();

                for (String queryTerm : queryTerms) {
                    if (invertedIndex.containsKey(queryTerm)) {
                        List<String> containingDocuments = invertedIndex.get(queryTerm);
                        double inverseDocumentFrequency = Math
                                .log10(documentList.size() / (double) documentFrequencies.get(queryTerm));
                        if (containingDocuments.contains(document)) {
                            double termFrequencyInverseDocumentFrequency = (1
                                    + Math.log10(documentVector.getOrDefault(queryTerm, 0))) * inverseDocumentFrequency;
                            dotProduct += queryVector.get(queryTerm) * termFrequencyInverseDocumentFrequency;
                        }
                    }
                }

                for (String term : documentVector.keySet()) {
                    double inverseDocumentFrequency = Math
                            .log10(documentList.size() / (double) documentFrequencies.get(term));
                    double termFrequencyInverseDocumentFrequency = (1 + Math.log10(documentVector.get(term)))
                            * inverseDocumentFrequency;
                    documentLength += termFrequencyInverseDocumentFrequency * termFrequencyInverseDocumentFrequency;
                }

                documentSimilarities.put(document, dotProduct / (Math.sqrt(documentLength) * Math.sqrt(queryLength)));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return documentSimilarities;
    }

    public List<String> rankDocumentsBySimilarity(Map<String, Double> documentSimilarities) {
        List<Map.Entry<String, Double>> sortedList = new ArrayList<>(documentSimilarities.entrySet());
        sortedList.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));

        List<String> rankedDocuments = new ArrayList<>();
        for (Map.Entry<String, Double> entry : sortedList) {
            rankedDocuments.add(entry.getKey());
        }

        return rankedDocuments;
    }

    public static void main(String[] args) throws IOException {
        List<String> documents = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            documents.add("document" + i + ".txt");
        }

        DocumentRanker documentRanker = new DocumentRanker();
        documentRanker.buildInvertedIndex(documents);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a query: ");
        String query = scanner.nextLine().toLowerCase();

        Map<String, Double> documentSimilarities = documentRanker.calculateDocumentSimilarities(query);
        List<String> rankedDocuments = documentRanker.rankDocumentsBySimilarity(documentSimilarities);

        System.out.println("Ranked list of documents:");
        for (String document : rankedDocuments) {
            System.out.println(document + ": similarity (" + documentSimilarities.get(document) + ")");
        }
    }
}