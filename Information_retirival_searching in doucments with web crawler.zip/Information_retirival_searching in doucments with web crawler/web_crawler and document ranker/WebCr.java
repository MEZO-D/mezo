import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebCrawler {
    private static final int MAX_DEPTH = 2; // Maximum depth for crawling
    private static final int MAX_PAGES = 100; // Maximum number of pages to crawl
    private int pageCount = 0;

    public void getPageLinks(String URL, int depth) {
        if (depth <= MAX_DEPTH && pageCount < MAX_PAGES) {
            try {
                // Fetch the HTML code
                Document document = Jsoup.connect(URL).get();
                System.out.println("Crawling: " + URL);

                // Increment the page count
                pageCount++;

                // Parse the HTML to extract links to other URLs
                Elements linksOnPage = document.select("a[href]");
                for (Element page : linksOnPage) {
                    String nextURL = page.absUrl("href");
                    getPageLinks(nextURL, depth + 1);
                }
            } catch (IOException e) {
                System.err.println("For '" + URL + "': " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        WebCrawler webCrawler = new WebCrawler();
        String startingURL = "https://www.example.com"; // Replace with your desired starting URL
        webCrawler.getPageLinks(startingURL, 0);
    }
}
